﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","az",{button:"Kodun parçasını əlavə et",codeContents:"Kod",emptySnippetError:"Kodun parçasını boş ola bilməz",language:"Programlaşdırma dili",title:"Kodun parçasını",pathName:"kodun parçasını"});