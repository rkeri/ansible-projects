﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","hr",{button:"Ubaci isječak kôda",codeContents:"Sadržaj kôda",emptySnippetError:"Isječak kôda ne može biti prazan.",language:"Jezik",title:"Isječak kôda",pathName:"isječak kôda"});