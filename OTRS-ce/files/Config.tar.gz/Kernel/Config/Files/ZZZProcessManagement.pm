# OTRS config file (automatically generated)
# VERSION:1.1
package Kernel::Config::Files::ZZZProcessManagement;
use strict;
use warnings;
no warnings 'redefine'; ## no critic
use utf8;
sub Load {
    my ($File, $Self) = @_;
$Self->{'Process'} = {
  'Process-78b4dde3a2d6540e7166f1c8328efd94' => {
    'ChangeTime' => '2019-10-01 10:59:19',
    'CreateTime' => '2019-10-01 10:58:15',
    'Name' => 'test123',
    'Path' => {
      'Activity-37fd56b355bdcef1bb22f6fb3f3c0063' => {},
      'Activity-b41ee7f18d39c86e9d9a5eb7abc073cf' => {
        'Transition-219392196c5505e44d24fbb857bb9472' => {
          'ActivityEntityID' => 'Activity-37fd56b355bdcef1bb22f6fb3f3c0063'
        }
      }
    },
    'StartActivity' => 'Activity-b41ee7f18d39c86e9d9a5eb7abc073cf',
    'StartActivityDialog' => '',
    'State' => 'Inactive',
    'StateEntityID' => 'S2'
  },
  'Process-8f7c4883a16f7beabf1760f0a7c729c4' => {
    'ChangeTime' => '2019-02-25 08:26:42',
    'CreateTime' => '2019-02-25 08:26:42',
    'Name' => 'teszt',
    'Path' => {},
    'StartActivity' => '',
    'StartActivityDialog' => '',
    'State' => 'Inactive',
    'StateEntityID' => 'S2'
  }
};

$Self->{'Process::State'} = {
  'S1' => 'Active',
  'S2' => 'Inactive',
  'S3' => 'FadeAway'
};

$Self->{'Process::Activity'} = {
  'Activity-37fd56b355bdcef1bb22f6fb3f3c0063' => {
    'ActivityDialog' => '',
    'ChangeTime' => '2019-02-25 09:21:00',
    'CreateTime' => '2019-02-25 09:21:00',
    'ID' => '2',
    'Name' => 'teszt 2'
  },
  'Activity-b41ee7f18d39c86e9d9a5eb7abc073cf' => {
    'ActivityDialog' => '',
    'ChangeTime' => '2019-07-03 09:29:30',
    'CreateTime' => '2019-07-03 09:29:30',
    'ID' => '3',
    'Name' => 'teszt 3'
  },
  'Activity-bed17fe6afe0b122580b3342426f38b1' => {
    'ActivityDialog' => '',
    'ChangeTime' => '2019-02-25 08:27:41',
    'CreateTime' => '2019-02-25 08:27:41',
    'ID' => '1',
    'Name' => 'teszt 1'
  }
};

$Self->{'Process::ActivityDialog'} = {};

$Self->{'Process::Transition'} = {
  'Transition-219392196c5505e44d24fbb857bb9472' => {
    'ChangeTime' => '2019-07-03 09:28:57',
    'Condition' => {
      '1' => {
        'Fields' => {
          'teszt 2' => {
            'Match' => 'teszt 2',
            'Type' => 'Module'
          }
        },
        'Type' => 'and'
      }
    },
    'ConditionLinking' => 'and',
    'CreateTime' => '2019-07-03 09:28:57',
    'Name' => 'tovább 2'
  },
  'Transition-5369721109a2bcf5b0cb7f30879ee063' => {
    'ChangeTime' => '2019-07-03 09:27:58',
    'Condition' => {
      '1' => {
        'Fields' => {
          'teszt 1' => {
            'Match' => 'teszt 2',
            'Type' => 'Module'
          }
        },
        'Type' => 'and'
      }
    },
    'ConditionLinking' => 'and',
    'CreateTime' => '2019-07-03 09:27:58',
    'Name' => 'tovább'
  },
  'Transition-bde9113d0fac1edb20b72f7548cd735c' => {
    'ChangeTime' => '2019-07-03 09:30:25',
    'Condition' => {
      '1' => {
        'Fields' => {
          'teszt 2' => {
            'Match' => 'teszt 3',
            'Type' => 'Module'
          }
        },
        'Type' => 'and'
      }
    },
    'ConditionLinking' => 'and',
    'CreateTime' => '2019-07-03 09:30:25',
    'Name' => 'tovább 3'
  }
};

$Self->{'Process::TransitionAction'} = {
  'TransitionAction-8a980ecde5257554d87a2f0660ad0884' => {
    'ChangeTime' => '2019-07-03 09:20:25',
    'Config' => {
      '' => ''
    },
    'CreateTime' => '2019-07-03 09:20:25',
    'Module' => 'Kernel::System::ProcessManagement::TransitionAction::DynamicFieldSet',
    'Name' => 'teszt'
  }
};

    return;
}
1;
