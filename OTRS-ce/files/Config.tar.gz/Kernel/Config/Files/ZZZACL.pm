# OTRS config file (automatically generated)
# VERSION:1.1
package Kernel::Config::Files::ZZZACL;
use strict;
use warnings;
no warnings 'redefine'; ## no critic
use utf8;
sub Load {
    my ($File, $Self) = @_;

# Created: 2020-01-23 14:04:35 (SallaiT)
# Changed: 2020-04-24 15:31:40 (SallaiT)
$Self->{TicketAcl}->{'1.1 Új ticketek - level 1 -> Open ticketek - level 1'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 2',
        'Review ticketek - level 2',
        'Review ticketek - level 1'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 1'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-19 12:16:30 (SallaiT)
# Changed: 2020-04-24 12:26:56 (SallaiT)
$Self->{TicketAcl}->{'1.2 Open ticketek - level 1 -> Review ticketek - level 1'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 1',
        'Open ticketek - level 2',
        'Review ticketek - level 2'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 1'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-02 11:34:06 (SallaiT)
# Changed: 2020-04-24 15:36:26 (SallaiT)
$Self->{TicketAcl}->{'1.3 Review ticketek - level 1 -> Open ticketek - level 1'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 1',
        'Open ticketek - level 2',
        'Review ticketek - level 2',
        'Új ticketek - level 2'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 1'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-19 10:29:34 (SallaiT)
# Changed: 2020-04-24 15:10:57 (SallaiT)
$Self->{TicketAcl}->{'1.4 Új ticketek - level 2 -> Open ticketek - level 2'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 1',
        'Review ticketek - level 1',
        'Review ticketek - level 2'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-02 13:09:38 (SallaiT)
# Changed: 2020-04-24 15:10:49 (SallaiT)
$Self->{TicketAcl}->{'1.5 Open ticketek - level 2 -> Review ticketek - level 2'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 1',
        'Review ticketek - level 1',
        'Új ticketek - level 2'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-02 13:14:10 (SallaiT)
# Changed: 2020-04-24 15:36:17 (SallaiT)
$Self->{TicketAcl}->{'1.6 Review ticketek - level 2 -> Open ticketek - level 2'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 2',
        'Review ticketek - level 1',
        'Új ticketek - level 1'
      ]
    }
  },
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-19 11:41:27 (SallaiT)
# Changed: 2020-04-03 11:16:24 (SallaiT)
$Self->{TicketAcl}->{'2.1 Új ticketek queues -> new state only'} = {
  'Possible' => {
    'Ticket' => {
      'State' => [
        'new'
      ]
    }
  },
  'PossibleAdd' => {},
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Új ticketek - level 1',
        'Új ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-19 11:08:08 (SallaiT)
# Changed: 2020-04-02 15:22:02 (SallaiT)
$Self->{TicketAcl}->{'2.2 Open ticketek queues -> open state only'} = {
  'Possible' => {
    'Ticket' => {
      'State' => [
        'open'
      ]
    }
  },
  'PossibleAdd' => {},
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Open ticketek - level 1',
        'Open ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-19 15:00:07 (SallaiT)
# Changed: 2020-04-14 12:47:10 (SallaiT)
$Self->{TicketAcl}->{'2.3 Review ticketek - level 1 -> states'} = {
  'Possible' => {
    'Ticket' => {
      'State' => [
        'review',
        'closed successful',
        'waiting for response'
      ]
    }
  },
  'PossibleAdd' => {},
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 1'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-14 12:39:02 (SallaiT)
# Changed: 2020-04-15 12:44:22 (SallaiT)
$Self->{TicketAcl}->{'2.4 Review ticketek - level 2 -> states'} = {
  'Possible' => {
    'Ticket' => {
      'State' => [
        'review'
      ]
    }
  },
  'PossibleAdd' => {},
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-15 12:44:57 (SallaiT)
# Changed: 2020-04-15 13:15:05 (SallaiT)
$Self->{TicketAcl}->{'2.5 Review ticketek - level 2 -> states +'} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Ticket' => {
      'State' => [
        'waiting for vendor response'
      ]
    }
  },
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 2'
      ],
      'State' => [
        'review'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-04-15 12:56:51 (SallaiT)
# Changed: 2020-04-15 13:17:13 (SallaiT)
$Self->{TicketAcl}->{'2.6 Review ticketek - level 2 -> states ++'} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Ticket' => {
      'State' => [
        'waiting for vendor response'
      ]
    }
  },
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 2'
      ],
      'State' => [
        'waiting for vendor response'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-20 09:13:41 (SallaiT)
# Changed: 2020-04-22 13:44:30 (SallaiT)
# Comment: funkciók tiltása
$Self->{TicketAcl}->{'3.1 Forward,Reply,Close és egyéb funkciók tiltása'} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Action' => [
      'AgentTicketMerge',
      'AgentSplitSelection',
      'AgentTicketPending',
      'AgentTicketPrint',
      'AgentTicketForward',
      'AgentTicketCompose',
      'AgentTicketOwner',
      'AgentTicketBulk',
      'AgentTicketHistory'
    ]
  },
  'Properties' => {},
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-20 13:26:52 (SallaiT)
# Changed: 2020-04-06 11:40:42 (SallaiT)
$Self->{TicketAcl}->{'3.2 Reply engedélyezése level 1 reviewon'} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Action' => [
      'AgentTicketCompose'
    ]
  },
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Lock' => [
        'lock'
      ],
      'Queue' => [
        'Review ticketek - level 1'
      ],
      'State' => [
        'review',
        'waiting for response'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2019-12-20 09:38:27 (SallaiT)
# Changed: 2020-04-05 21:26:50 (SallaiT)
$Self->{TicketAcl}->{'3.3 Forward engedélyezése level 2 reviewen'} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Action' => [
      'AgentTicketForward'
    ]
  },
  'PossibleNot' => {},
  'Properties' => {
    'Ticket' => {
      'Queue' => [
        'Review ticketek - level 2'
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2020-01-08 11:52:41 (SallaiT)
# Changed: 2020-04-08 15:55:02 (SallaiT)
$Self->{TicketAcl}->{'3.4 Owner váltás engedélyezése'} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Action' => [
      'AgentTicketOwner'
    ]
  },
  'PossibleNot' => {},
  'Properties' => {},
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

    return;
}
1;
